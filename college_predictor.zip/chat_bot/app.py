from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)

# Load dataset once
df = pd.read_csv("combined_lopenh_cutoffs.csv")
df.columns = df.columns.str.strip()
df.rename(columns={'Rank': 'Closing Rank', 'College': 'College Name'}, inplace=True)

# Recommender function
def recommend(rank, branch=None):
    high, mid, low = [], [], []

    for _, row in df.iterrows():
        cutoff = row['Closing Rank']
        br = str(row['Branch'])

        if branch and branch.lower() not in br.lower():
            continue

        diff = cutoff - rank

        if diff >= 0 and diff <= 5000:
            high.append(row)
        elif abs(rank - cutoff) <= 5000:
            mid.append(row)
        else:
            low.append(row)

    return pd.DataFrame(high), pd.DataFrame(mid), pd.DataFrame(low)

# Route
@app.route('/', methods=['GET', 'POST'])
def index():
    results = None
    if request.method == 'POST':
        rank = int(request.form['rank'])
        branch = request.form['branch'].strip()
        branch = branch if branch else None

        high_df, mid_df, low_df = recommend(rank, branch)

        results = {
            'high': high_df[['College Name', 'Branch', 'Closing Rank']].head(10).to_dict(orient='records'),
            'mid': mid_df[['College Name', 'Branch', 'Closing Rank']].head(10).to_dict(orient='records'),
            'low': low_df[['College Name', 'Branch', 'Closing Rank']].head(10).to_dict(orient='records')
        }

    return render_template('index.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
